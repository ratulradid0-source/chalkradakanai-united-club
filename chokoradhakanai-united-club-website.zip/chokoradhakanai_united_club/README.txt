# চকরাধাকানাই ইউনাইটেড ক্লাব — ওয়েবসাইট

এই ফোল্ডারটি একটি সম্পূর্ণ static website। কোনো paid hosting লাগবে না।

## সবচেয়ে সহজে Publish: GitHub Pages

1. GitHub-এ একটি account খুলুন/লগইন করুন: https://github.com/
2. New repository তৈরি করুন। Repository-এর নাম দিতে পারেন:
   `chokoradhakanai-united-club`
3. এই ফোল্ডারের `index.html`, `style.css`, `script.js` এবং `images` folder repository-তে upload করুন।
4. Repository → Settings → Pages-এ যান।
5. Source হিসেবে `Deploy from a branch` নির্বাচন করুন।
6. Branch হিসেবে `main` এবং folder হিসেবে `/ (root)` নির্বাচন করে Save দিন।
7. কিছুক্ষণ পর GitHub একটি website address দেবে।

## Google-এ দেখানোর জন্য

Website live হওয়ার পরে Google Search Console-এ site যোগ করে indexing request করা ভালো:
https://search.google.com/search-console/

## গুরুত্বপূর্ণ

- Facebook link ইতোমধ্যে বসানো আছে।
- Google Maps-এর search link দেওয়া আছে; exact pin/coordinates পরে যোগ করা যাবে।
- Gallery-তে ছবি চাপলে বড় করে দেখা যাবে।
- নতুন ছবি দিতে চাইলে `images` folder-এ ছবি রেখে `index.html`-এর gallery অংশে নাম পরিবর্তন করুন।
