const menuBtn=document.querySelector(".menu-btn"),nav=document.querySelector("#nav");
menuBtn?.addEventListener("click",()=>{const open=nav.classList.toggle("open");menuBtn.setAttribute("aria-expanded",open)});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
const modal=document.querySelector("#modal"),modalImg=document.querySelector("#modalImg");
document.querySelectorAll(".photo").forEach(btn=>btn.addEventListener("click",()=>{modalImg.src=btn.dataset.full;modal.classList.add("show");modal.setAttribute("aria-hidden","false")}));
document.querySelector(".modal-close")?.addEventListener("click",closeModal);
modal?.addEventListener("click",e=>{if(e.target===modal)closeModal()});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModal()});
function closeModal(){modal.classList.remove("show");modal.setAttribute("aria-hidden","true");modalImg.src=""}
document.querySelector("#year").textContent=new Date().getFullYear();
